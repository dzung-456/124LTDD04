package com.example.dangngocdung_contentprovider;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.MediaStore;
import android.app.Activity;
import android.content.CursorLoader;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
    private BookmarkDatabaseHelper dbHelper;
    Button btnshowallcontact;
    Button btnaccesscalllog;
    Button btnaccessmediastore;
    Button btnaccessbookmarks;
    private static final int PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new BookmarkDatabaseHelper(this);

        // Thêm dấu trang ví dụ
        addBookmark("OpenAI", "https://www.openai.com");
        showBookmarks();

        // Kiểm tra quyền truy cập
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }

        // Khởi tạo các nút
        btnshowallcontact = findViewById(R.id.btnshowallcontact);
        btnshowallcontact.setOnClickListener(this);
        btnaccesscalllog = findViewById(R.id.btnaccesscalllog);
        btnaccesscalllog.setOnClickListener(this);
        btnaccessmediastore = findViewById(R.id.btnmediastore);
        btnaccessmediastore.setOnClickListener(this);
        btnaccessbookmarks = findViewById(R.id.btnaccessbookmarks);
        btnaccessbookmarks.setOnClickListener(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        if (v == btnshowallcontact) {
            intent = new Intent(this, ShowAllContactActivity.class);
            startActivity(intent);
        } else if (v == btnaccesscalllog) {
            accessTheCallLog();
        } else if (v == btnaccessmediastore) {
            accessMediaStore();
        } else if (v == btnaccessbookmarks) {
            showBookmarks();
        }
    }

    // Hàm lấy danh sách lịch sử cuộc gọi
    public void accessTheCallLog() {
        String[] projection = new String[]{
                CallLog.Calls.DATE,
                CallLog.Calls.NUMBER,
                CallLog.Calls.DURATION
        };
        Cursor c = getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                projection,
                CallLog.Calls.DURATION + "<?", new String[]{"30"},
                CallLog.Calls.DATE + " ASC");

        if (c != null) {
            StringBuilder s = new StringBuilder();
            while (c.moveToNext()) {
                for (int i = 0; i < c.getColumnCount(); i++) {
                    s.append(c.getString(i)).append(" - ");
                }
                s.append("\n");
            }
            c.close();
            Toast.makeText(this, s.toString(), Toast.LENGTH_LONG).show();
        }
    }

    // Hàm đọc danh sách các Media trong SD CARD
    public void accessMediaStore() {
        String[] projection = {
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.MIME_TYPE
        };
        // Sử dụng MediaStore.Images.Media.EXTERNAL_CONTENT_URI hoặc MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        CursorLoader loader = new CursorLoader(
                this, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, null);
        Cursor c = loader.loadInBackground();

        if (c != null) {
            StringBuilder s = new StringBuilder();
            while (c.moveToNext()) {
                for (int i = 0; i < c.getColumnCount(); i++) {
                    s.append(c.getString(i)).append(" - ");
                }
                s.append("\n");
            }
            Toast.makeText(this, s.toString(), Toast.LENGTH_LONG).show();
            c.close();
        }
    }


    // Hàm thêm dấu trang
    private void addBookmark(String title, String url) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(BookmarkDatabaseHelper.COLUMN_TITLE, title);
        values.put(BookmarkDatabaseHelper.COLUMN_URL, url);
        db.insert(BookmarkDatabaseHelper.TABLE_NAME, null, values);
        db.close();
    }

    // Hàm hiển thị danh sách dấu trang
    private void showBookmarks() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                BookmarkDatabaseHelper.COLUMN_TITLE,
                BookmarkDatabaseHelper.COLUMN_URL
        };

        Cursor cursor = db.query(
                BookmarkDatabaseHelper.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null) {
            StringBuilder s = new StringBuilder();
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(BookmarkDatabaseHelper.COLUMN_TITLE));
                String url = cursor.getString(cursor.getColumnIndexOrThrow(BookmarkDatabaseHelper.COLUMN_URL));
                s.append(title).append(" - ").append(url).append("\n");
            }
            cursor.close();
            Toast.makeText(this, s.toString(), Toast.LENGTH_LONG).show();
        }
    }
}
